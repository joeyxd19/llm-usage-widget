# -*- coding: utf-8 -*-
"""
额度悬浮窗 - 智谱 GLM Coding Plan + 火山引擎 Agent Plan 桌面常驻用量监控

- 零第三方依赖，仅需 Python 3.8+（Windows 官方安装包自带 tkinter）
- 双击本文件即可运行（.pyw = 无黑窗口）
- 右键菜单：立即刷新 / 编辑配置 / 开机自启 / 退出
- 拖动任意位置移动窗口，位置自动记忆
"""

import datetime
import hashlib
import hmac
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

try:
    import tkinter as tk
    from tkinter import font as tkfont
    TK_AVAILABLE = True
except ImportError:  # 允许无图形环境下导入 API 层
    TK_AVAILABLE = False
    tk = None
    tkfont = None

APP_NAME = "额度悬浮窗"
APP_VERSION = "1.0"
CONFIG_NAME = "config.json"

# --------------------------------------------------------------------------
# 配置
# --------------------------------------------------------------------------

DEFAULT_CONFIG = {
    "zhipu": {
        "enabled": True,
        "api_key": "在这里填你的智谱API_Key",
        "base_url": "open.bigmodel.cn",
    },
    "volcano": {
        "enabled": True,
        "access_key_id": "在这里填火山AccessKeyID_AKLT开头",
        "secret_access_key": "在这里填火山SecretAccessKey",
        "region": "cn-beijing",
    },
    "refresh_minutes": 5,
    "opacity": 0.96,
    "warn_percent": 80,
    "critical_percent": 95,
    "window_x": 120,
    "window_y": 120,
}


def app_dir():
    if getattr(sys, "frozen", False):  # PyInstaller 打包后
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def config_path():
    return os.path.join(app_dir(), CONFIG_NAME)


def load_config():
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))  # deep copy
    try:
        with open(config_path(), "r", encoding="utf-8") as f:
            user = json.load(f)
        for section in ("zhipu", "volcano"):
            if isinstance(user.get(section), dict):
                cfg[section].update(user[section])
        for key in ("refresh_minutes", "opacity", "warn_percent",
                    "critical_percent", "window_x", "window_y"):
            if key in user:
                cfg[key] = user[key]
    except FileNotFoundError:
        save_config(cfg)
    except Exception:
        pass
    return cfg


def save_config(cfg):
    try:
        with open(config_path(), "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def is_placeholder(value):
    return (not value) or ("这里填" in str(value)) or str(value).strip() == ""


# --------------------------------------------------------------------------
# HTTP 基础
# --------------------------------------------------------------------------

def http_json(url, headers=None, data=None, timeout=15):
    """发起请求，返回 (status_code, dict|str)"""
    req = urllib.request.Request(url, headers=headers or {},
                                 data=data, method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
            code = resp.status
    except urllib.error.HTTPError as e:
        raw = e.read().decode("utf-8", "replace")
        code = e.code
    except Exception as e:
        return 0, "网络错误: %s" % e
    try:
        return code, json.loads(raw)
    except Exception:
        return code, raw


# --------------------------------------------------------------------------
# 智谱 GLM Coding Plan
# --------------------------------------------------------------------------

def fetch_zhipu(zcfg):
    """
    GET https://open.bigmodel.cn/api/monitor/usage/quota/limit
    认证: Authorization: <API_KEY>（不带 Bearer）
    返回: {"ok": bool, "level": str, "five_hour": pct, "weekly": pct,
           "mcp": {"used": n, "total": n, "percent": pct}, "error": str}
    """
    result = {"ok": False, "level": "", "five_hour": None,
              "weekly": None, "mcp": None, "error": ""}
    key = zcfg.get("api_key", "")
    if is_placeholder(key):
        result["error"] = "未配置 API Key"
        return result
    base = (zcfg.get("base_url") or "open.bigmodel.cn").strip().rstrip("/")
    if not base.startswith("http"):
        base = "https://" + base
    url = base + "/api/monitor/usage/quota/limit"
    code, body = http_json(url, headers={
        "Authorization": key,
        "Content-Type": "application/json",
        "User-Agent": "usage-widget/" + APP_VERSION,
    })
    if code == 0:
        result["error"] = str(body)
        return result
    if not isinstance(body, dict) or not body.get("success"):
        msg = body.get("msg") if isinstance(body, dict) else str(body)[:80]
        result["error"] = "HTTP %s %s" % (code, msg or "查询失败")
        return result

    data = body.get("data") or {}
    result["level"] = str(data.get("level") or "").upper()
    limits = data.get("limits") or []

    tokens = [l for l in limits if l.get("type") == "TOKENS_LIMIT"]
    # 两个 TOKENS_LIMIT：nextResetTime 早的是 5 小时窗口，晚的是周窗口
    try:
        tokens.sort(key=lambda l: l.get("nextResetTime") or 0)
    except Exception:
        pass
    if len(tokens) >= 1:
        result["five_hour"] = tokens[0].get("percentage")
    if len(tokens) >= 2:
        result["weekly"] = tokens[1].get("percentage")

    mcp = next((l for l in limits if l.get("type") == "TIME_LIMIT"), None)
    if mcp:
        total = mcp.get("usage") or 0
        used = mcp.get("currentValue") or 0
        pct = mcp.get("percentage")
        if pct is None and total:
            pct = round(used * 100.0 / total, 1)
        result["mcp"] = {"used": used, "total": total, "percent": pct}

    result["ok"] = True
    return result


# --------------------------------------------------------------------------
# 火山引擎 Agent Plan（Volcano Signature V4，AWS SigV4 变体）
# --------------------------------------------------------------------------

def _hmac_sha256(key, msg):
    if isinstance(key, str):
        key = key.encode("utf-8")
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def fetch_volcano(vcfg):
    """
    POST https://ark.<region>.volcengineapi.com/?Action=GetAFPUsage&Version=2024-01-01
    返回: {"ok": bool, "level": str, "windows": [(名称, used, quota, reset_ms)], "error": str}
    """
    result = {"ok": False, "level": "", "windows": [], "error": ""}
    ak = vcfg.get("access_key_id", "")
    sk = vcfg.get("secret_access_key", "")
    if is_placeholder(ak) or is_placeholder(sk):
        result["error"] = "未配置 AK/SK"
        return result
    region = vcfg.get("region") or "cn-beijing"
    host = "ark.%s.volcengineapi.com" % region
    service = "ark"

    # 1. 基础信息
    now = datetime.datetime.utcnow()
    x_date = now.strftime("%Y%m%dT%H%M%SZ")
    short_date = x_date[:8]
    body = "{}"
    payload_hash = hashlib.sha256(body.encode("utf-8")).hexdigest()
    content_type = "application/json; charset=utf-8"

    # 2. 规范请求（canonical headers 按字母序: content-type;host;x-content-sha256;x-date）
    query = "Action=GetAFPUsage&Version=2024-01-01"
    signed_headers = "content-type;host;x-content-sha256;x-date"
    canonical_headers = (
        "content-type:%s\nhost:%s\nx-content-sha256:%s\nx-date:%s\n"
        % (content_type, host, payload_hash, x_date)
    )
    canonical_request = "\n".join([
        "POST", "/", query, canonical_headers, signed_headers, payload_hash,
    ])

    # 3. 签名串与派生密钥
    scope = "%s/%s/%s/request" % (short_date, region, service)
    string_to_sign = "\n".join([
        "HMAC-SHA256", x_date, scope,
        hashlib.sha256(canonical_request.encode("utf-8")).hexdigest(),
    ])
    k_date = _hmac_sha256(sk.encode("utf-8"), short_date)
    k_region = _hmac_sha256(k_date, region)
    k_service = _hmac_sha256(k_region, service)
    k_signing = _hmac_sha256(k_service, "request")
    signature = hmac.new(k_signing, string_to_sign.encode("utf-8"),
                         hashlib.sha256).hexdigest()

    authorization = ("HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s"
                     % (ak, scope, signed_headers, signature))

    url = "https://%s/?%s" % (host, query)
    code, body = http_json(url, headers={
        "Content-Type": content_type,
        "Host": host,
        "X-Date": x_date,
        "X-Content-Sha256": payload_hash,
        "Authorization": authorization,
        "User-Agent": "usage-widget/" + APP_VERSION,
    }, data=body.encode("utf-8"))

    if code == 0:
        result["error"] = str(body)
        return result
    if not isinstance(body, dict):
        result["error"] = "HTTP %s %s" % (code, str(body)[:80])
        return result
    meta = body.get("ResponseMetadata") or {}
    if meta.get("Error"):
        err = meta["Error"]
        result["error"] = "%s: %s" % (err.get("Code", "Error"),
                                      (err.get("Message") or "")[:80])
        return result

    res = body.get("Result") or {}
    result["level"] = str(res.get("PlanType") or "")
    for key, name in (("AFPFiveHour", "5小时"), ("AFPDaily", "今日"),
                      ("AFPWeekly", "本周"), ("AFPMonthly", "本月")):
        w = res.get(key)
        if isinstance(w, dict) and w.get("Quota"):
            result["windows"].append((name, w.get("Used", 0), w["Quota"],
                                      w.get("ResetTime") or 0))
    result["ok"] = True
    return result


# --------------------------------------------------------------------------
# UI
# --------------------------------------------------------------------------

C_BG        = "#17181d"   # 窗体背景（同时也是透明色）
C_CARD      = "#232429"   # 卡片
C_CARD_LINE = "#2e3038"
C_TEXT      = "#e8eaed"
C_TEXT_DIM  = "#9aa0a6"
C_TRACK     = "#3a3d46"   # 进度条底槽
C_GREEN     = "#4ade80"
C_YELLOW    = "#fbbf24"
C_RED       = "#f87171"
C_ACCENT_Z  = "#7aa2ff"   # 智谱品牌蓝
C_ACCENT_V  = "#ff7a90"   # 火山品牌红粉

W_WIDTH = 272
PAD = 14
ROW_H = 30
BAR_H = 8
BAR_X0 = 78          # 进度条起点 x
BAR_X1 = W_WIDTH - 66  # 进度条终点 x
PCT_X = W_WIDTH - 58   # 百分比文字 x

FONT_FAMILY_CANDIDATES = ["Microsoft YaHei UI", "Microsoft YaHei",
                          "PingFang SC", "Noto Sans CJK SC", "WenQuanYi Micro Hei"]


class UsageWidget:
    def __init__(self, root):
        self.root = root
        self.cfg = load_config()
        self.data = {"zhipu": None, "volcano": None}
        self.errors = {"zhipu": "", "volcano": ""}
        self.last_ok_time = None
        self.updating = False

        self._pick_font()
        self._build_window()
        self._build_menu()
        self._bind_events()

        self.redraw()
        self.root.after(300, self.refresh_async)

    # ---------------- 窗口与字体 ----------------

    def _pick_font(self):
        available = set(tkfont.families(self.root))
        self.font_family = "TkDefaultFont"
        for f in FONT_FAMILY_CANDIDATES:
            if f in available:
                self.font_family = f
                break
        self.f_title = tkfont.Font(family=self.font_family, size=10, weight="bold")
        self.f_text = tkfont.Font(family=self.font_family, size=9)
        self.f_small = tkfont.Font(family=self.font_family, size=8)
        self.f_big = tkfont.Font(family=self.font_family, size=13, weight="bold")

    def _build_window(self):
        self.root.title(APP_NAME)
        self.root.overrideredirect(True)          # 无边框
        self.root.attributes("-topmost", True)     # 常驻置顶
        try:
            self.root.attributes("-alpha", float(self.cfg.get("opacity", 0.96)))
        except Exception:
            pass
        try:
            # Windows 下用透明色实现圆角外形；失败则退化为直角
            self.root.attributes("-transparentcolor", C_BG)
            self.transparent = True
        except Exception:
            self.transparent = False

        self.canvas = tk.Canvas(self.root, bg=C_BG, highlightthickness=0,
                                bd=0, width=W_WIDTH, height=100)
        self.canvas.pack(fill="both", expand=True)
        self.root.resizable(False, False)

    def _build_menu(self):
        self.menu = tk.Menu(self.root, tearoff=0,
                            font=(self.font_family, 9), bd=1, relief="solid")
        self.menu.add_command(label="立即刷新", command=self.refresh_async)
        self.menu.add_command(label="编辑配置 (config.json)",
                              command=self.open_config)
        self.menu.add_separator()
        self.auto_menu = tk.Menu(self.menu, tearoff=0,
                                 font=(self.font_family, 9))
        self.auto_menu.add_command(label="设置开机自启", command=self.enable_autostart)
        self.auto_menu.add_command(label="取消开机自启", command=self.disable_autostart)
        self.menu.add_cascade(label="开机自启", menu=self.auto_menu)
        self.menu.add_separator()
        self.menu.add_command(label="退出", command=self.quit)

    def _bind_events(self):
        c = self.canvas
        c.bind("<Button-1>", self._on_drag_start)
        c.bind("<B1-Motion>", self._on_drag_motion)
        c.bind("<ButtonRelease-1>", self._on_drag_end)
        c.bind("<Button-3>", self._on_right_click)   # Windows 右键
        c.bind("<Button-2>", self._on_right_click)   # macOS 右键
        # 双击标题区切换精简模式（预留）
        self._drag_offset = None
        self._moved = False

    # ---------------- 拖动 / 菜单 ----------------

    def _on_drag_start(self, event):
        self._drag_offset = (event.x, event.y)
        self._moved = False

    def _on_drag_motion(self, event):
        if not self._drag_offset:
            return
        dx, dy = event.x - self._drag_offset[0], event.y - self._drag_offset[1]
        if abs(dx) + abs(dy) > 2:
            self._moved = True
        x = self.root.winfo_x() + dx
        y = self.root.winfo_y() + dy
        self.root.geometry("+%d+%d" % (x, y))

    def _on_drag_end(self, event):
        if self._moved:
            self.cfg["window_x"] = self.root.winfo_x()
            self.cfg["window_y"] = self.root.winfo_y()
            save_config(self.cfg)
        self._drag_offset = None

    def _on_right_click(self, event):
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def open_config(self):
        path = config_path()
        if os.name == "nt":
            os.startfile(path)  # noqa
        else:
            import subprocess
            for editor in ("gedit", "xdg-open", "open"):
                try:
                    subprocess.Popen([editor, path])
                    break
                except Exception:
                    continue

    # ---------------- 开机自启 ----------------

    def _autostart_file(self):
        if os.name != "nt":
            return None
        base = os.path.join(os.environ.get("APPDATA", ""),
                            "Microsoft", "Windows", "Start Menu",
                            "Programs", "Startup")
        return os.path.join(base, "usage_widget.vbs")

    def enable_autostart(self):
        path = self._autostart_file()
        if not path:
            self._toast("开机自启仅支持 Windows")
            return
        script = os.path.abspath(__file__)
        if getattr(sys, "frozen", False):
            inner = '"%s"' % os.path.abspath(sys.executable)
        else:
            # .pyw 默认由 pythonw 运行，sys.executable 即 pythonw.exe 完整路径
            inner = '"%s" "%s"' % (sys.executable, script)
        content = 'CreateObject("WScript.Shell").Run %s, 0, False\n' % inner
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "wb") as f:
                # WScript 按系统 ANSI(GBK) 读取 .vbs，二进制写入避免中文路径乱码
                f.write(content.encode("gbk", "replace"))
            self._toast("已设置开机自启")
        except Exception as e:
            self._toast("设置失败: %s" % e)

    def disable_autostart(self):
        path = self._autostart_file()
        if path and os.path.exists(path):
            try:
                os.remove(path)
                self._toast("已取消开机自启")
            except Exception as e:
                self._toast("取消失败: %s" % e)
        else:
            self._toast("当前没有开机自启")

    def quit(self):
        self.cfg["window_x"] = self.root.winfo_x()
        self.cfg["window_y"] = self.root.winfo_y()
        save_config(self.cfg)
        self.root.destroy()

    # ---------------- 数据刷新 ----------------

    def refresh_async(self):
        if self.updating:
            return
        self.updating = True
        self.status_text = "更新中…"
        self.redraw()

        def worker():
            zr, vr = None, None
            zcfg, vcfg = self.cfg.get("zhipu", {}), self.cfg.get("volcano", {})
            if zcfg.get("enabled", True):
                try:
                    zr = fetch_zhipu(zcfg)
                except Exception as e:
                    zr = {"ok": False, "error": str(e)[:80]}
            if vcfg.get("enabled", True):
                try:
                    vr = fetch_volcano(vcfg)
                except Exception as e:
                    vr = {"ok": False, "error": str(e)[:80]}
            self.root.after(0, lambda: self._apply_refresh(zr, vr))

        threading.Thread(target=worker, daemon=True).start()

    def _apply_refresh(self, zr, vr):
        self.updating = False
        now = datetime.datetime.now()
        any_ok = False
        if zr is not None:
            self.errors["zhipu"] = "" if zr.get("ok") else zr.get("error", "失败")
            if zr.get("ok"):
                self.data["zhipu"] = zr
                any_ok = True
        if vr is not None:
            self.errors["volcano"] = "" if vr.get("ok") else vr.get("error", "失败")
            if vr.get("ok"):
                self.data["volcano"] = vr
                any_ok = True
        if any_ok:
            self.last_ok_time = now
            self.status_text = "更新于 %s" % now.strftime("%H:%M")
        else:
            self.status_text = "更新失败 %s" % now.strftime("%H:%M")
        self.redraw()
        minutes = max(1, int(self.cfg.get("refresh_minutes", 5)))
        self.root.after(minutes * 60 * 1000, self.refresh_async)

    # ---------------- 绘制 ----------------

    def _color(self, percent):
        if percent is None:
            return C_TEXT_DIM
        if percent >= float(self.cfg.get("critical_percent", 95)):
            return C_RED
        if percent >= float(self.cfg.get("warn_percent", 80)):
            return C_YELLOW
        return C_GREEN

    def _round_rect(self, x0, y0, x1, y1, r, **kw):
        pts = [x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r,
               x1, y1 - r, x1, y1, x1 - r, y1,
               x0 + r, y1, x0, y1, x0, y1 - r, x0, y0 + r, x0, y0]
        return self.canvas.create_polygon(pts, smooth=True, **kw)

    def _card(self, y0, height):
        r = 14
        self._round_rect(PAD - 6, y0, W_WIDTH - PAD + 6, y0 + height, r,
                         fill=C_CARD, outline=C_CARD_LINE)
        return y0

    def _bar(self, y_center, percent, color):
        self.canvas.create_rectangle(BAR_X0, y_center - BAR_H // 2,
                                     BAR_X1, y_center + BAR_H // 2,
                                     fill=C_TRACK, width=0)
        if percent is None:
            return
        pct = max(0.0, min(100.0, float(percent)))
        w = int((BAR_X1 - BAR_X0) * pct / 100.0)
        if w > 1:
            self.canvas.create_rectangle(BAR_X0, y_center - BAR_H // 2,
                                         BAR_X0 + w, y_center + BAR_H // 2,
                                         fill=color, width=0)

    def _row(self, y, label, percent, right_text=None, sub=None):
        cy = y + ROW_H // 2
        self.canvas.create_text(PAD + 2, cy, text=label, anchor="w",
                                font=self.f_text, fill=C_TEXT_DIM)
        color = self._color(percent)
        self._bar(cy, percent, color)
        txt = right_text if right_text is not None else (
            "—" if percent is None else "%d%%" % round(percent))
        self.canvas.create_text(W_WIDTH - PAD, cy, text=txt, anchor="e",
                                font=self.f_text, fill=color)

    def _provider_title(self, y, name, level, accent, err):
        cy = y + 16
        self.canvas.create_text(PAD + 2, cy, text=name, anchor="w",
                                font=self.f_title, fill=C_TEXT)
        if level:
            tag_x = PAD + 2 + self.f_title.measure(name) + 8
            self.canvas.create_rectangle(tag_x, cy - 9,
                                         tag_x + self.f_small.measure(level) + 12,
                                         cy + 9,
                                         fill=self._dim(accent), width=0)
            self.canvas.create_text(tag_x + 6, cy,
                                    text=level, anchor="w", font=self.f_small,
                                    fill=C_TEXT)
        if err:
            self.canvas.create_text(W_WIDTH - PAD, cy, text="⚠ " + err[:16],
                                    anchor="e", font=self.f_small, fill=C_YELLOW)

    @staticmethod
    def _dim(color):
        mapping = {C_ACCENT_Z: "#2a3550", C_ACCENT_V: "#45242e"}
        return mapping.get(color, "#333")

    def redraw(self):
        c = self.canvas
        c.delete("all")

        show_z = self.cfg.get("zhipu", {}).get("enabled", True)
        show_v = self.cfg.get("volcano", {}).get("enabled", True)

        y = PAD - 2
        cards_h = []

        # ---- 智谱卡片 ----
        if show_z:
            zd = self.data.get("zhipu")
            rows = 3
            h = 34 + rows * ROW_H + 10
            self._card(y, h)
            level = (zd or {}).get("level") or ""
            self._provider_title(y, "智谱 Coding Plan", level, C_ACCENT_Z,
                                 self.errors["zhipu"])
            ry = y + 34
            if zd and zd.get("ok"):
                self._row(ry, "5小时", zd.get("five_hour")); ry += ROW_H
                self._row(ry, "本周", zd.get("weekly")); ry += ROW_H
                mcp = zd.get("mcp")
                if mcp:
                    right = ("%s/%s" % (self._fmt_num(mcp["used"]),
                                        self._fmt_num(mcp["total"])))
                    self._row(ry, "MCP月", mcp.get("percent"), right_text=right)
                else:
                    self._row(ry, "MCP月", None, right_text="—")
            else:
                hint = self.errors["zhipu"] or "待配置"
                c.create_text(W_WIDTH // 2, y + 34 + (h - 44) // 2,
                              text=hint[:18] if hint else "—",
                              font=self.f_small, fill=C_TEXT_DIM)
            cards_h.append(h)
            y += h + 8

        # ---- 火山卡片 ----
        if show_v:
            vd = self.data.get("volcano")
            rows = 4
            h = 34 + rows * ROW_H + 10
            self._card(y, h)
            level = (vd or {}).get("level") or ""
            self._provider_title(y, "火山 Agent Plan", level, C_ACCENT_V,
                                 self.errors["volcano"])
            ry = y + 34
            if vd and vd.get("ok"):
                for name, used, quota, reset in vd.get("windows", []):
                    pct = round(used * 100.0 / quota, 1) if quota else None
                    right = "%d%%" % round(pct) if pct is not None else "—"
                    self._row(ry, name, pct, right_text=right)
                    ry += ROW_H
                for _ in range(rows - len(vd.get("windows", []))):
                    self._row(ry, "—", None); ry += ROW_H
            else:
                hint = self.errors["volcano"] or "待配置"
                c.create_text(W_WIDTH // 2, y + 34 + (h - 44) // 2,
                              text=hint[:18] if hint else "—",
                              font=self.f_small, fill=C_TEXT_DIM)
            cards_h.append(h)
            y += h + 8

        if not show_z and not show_v:
            self._card(y, 60)
            c.create_text(W_WIDTH // 2, y + 30, text="两个供应商均已停用",
                          font=self.f_text, fill=C_TEXT_DIM)
            y += 68

        # ---- 状态栏 ----
        status = getattr(self, "status_text", "启动中…")
        c.create_text(PAD + 2, y + 9, text=status, anchor="w",
                      font=self.f_small,
                      fill=C_TEXT_DIM if "失败" not in status else C_YELLOW)
        c.create_text(W_WIDTH - PAD, y + 9, text="右键菜单 · 拖动移动",
                      anchor="e", font=self.f_small, fill=C_TEXT_DIM)

        total_h = y + 22 + PAD // 2
        c.configure(height=total_h)
        geo = "%dx%d" % (W_WIDTH, total_h)
        if not getattr(self, "_placed", False):
            geo += "+%d+%d" % (int(self.cfg.get("window_x", 120)),
                               int(self.cfg.get("window_y", 120)))
            self._placed = True
        # 首次按配置定位，之后只调尺寸不重置位置（避免拖动后被刷新弹回）
        self.root.geometry(geo)

    @staticmethod
    def _fmt_num(n):
        try:
            n = float(n)
            if n >= 10000:
                return "%.1fw" % (n / 10000)
            if n == int(n):
                return str(int(n))
            return "%.1f" % n
        except Exception:
            return str(n)

    def _toast(self, msg):
        self.status_text = msg
        self.redraw()


def main():
    if not TK_AVAILABLE:
        print("未检测到 tkinter。请从 python.org 安装 Python（勾选 tcl/tk 组件）后重试。")
        sys.exit(1)
    root = tk.Tk()
    try:
        root.call("tk", "scaling", 1.25)
    except Exception:
        pass
    app = UsageWidget(root)  # noqa: F841
    root.mainloop()


if __name__ == "__main__":
    main()
